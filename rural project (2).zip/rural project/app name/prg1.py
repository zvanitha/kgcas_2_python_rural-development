from flask import *
app = Flask(__name__)

@app.route("/loginpage")
def loginpage():
    return render_template("loginpage.html")
    
@app.route("/regfrm")
def regfrm():
    return render_template("regfrm.html")
    
if __name__=='__main__':
	app.run()
